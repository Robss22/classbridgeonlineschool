

export default function AdminLayout({ children }) {
  return children;
} 