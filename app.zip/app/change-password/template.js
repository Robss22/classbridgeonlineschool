export default function Template({ children }) {
  return children;
} 